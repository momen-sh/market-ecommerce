export * from './item-details.component';
