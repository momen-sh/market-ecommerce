export enum Categories {
  All = 'All',
  Computers = 'Computers',
  Phones = 'Phones',
  Audio = 'Audio',
  Gaming = 'Gaming',
  PlayStation = 'PlayStation',
  Xbox = 'Xbox',
  Accessories = 'Accessories',
  Other = 'Other'
}
