export const environment = {
  production: false,
  apiUrl: 'https://localhost:44375/api',
  imgUrl: 'https://localhost:44375/uploads/products'
};
