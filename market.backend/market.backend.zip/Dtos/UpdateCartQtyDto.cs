﻿public class UpdateCartQtyDto
{
    public int Quantity { get; set; }
}