﻿namespace market.Repositories
{
    public class UserRepository
    {
    }
}
