﻿namespace market.Repositories
{
    public class CartRepository
    {
    }
}
