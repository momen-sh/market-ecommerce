﻿namespace market.Repositories.Interfaces
{
    public class ICartRepository
    {
    }
}
