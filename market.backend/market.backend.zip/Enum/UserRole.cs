﻿namespace market.Models
{
    public enum UserRole
    {
        User = 0,
        Admin = 1
    }
}
